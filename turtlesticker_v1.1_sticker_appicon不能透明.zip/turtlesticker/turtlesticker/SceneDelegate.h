//
//  SceneDelegate.h
//  turtlesticker
//
//  Created by beyond on 2020/4/11.
//  Copyright © 2020 cn18x. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

